esta tabla debe ser utilizada ([Table 1](?tab=t.0#bookmark=id.59306923ted5))






| **Código de entrada**            | **Procedencia\***                | **Variedad**                     | **Nombre científico**            |                                  | **Fecha de ingreso**              |
|----------------------------------|----------------------------------|----------------------------------|----------------------------------|----------------------------------|-----------------------------------|
|                                  |                                  |                                  | Género                           | Especie                          |                                   |
| TT-001                           | Arequipa / Arequipa /            | Negra                            | *Tropaelum*                      | *tuberosum*                      | 8/1/2025                          |
| TT-002                           | Arequipa / Arequipa /            | Amarilla con lineas negras       | *Tropaelum*                      | *tuberosum*                      | 8/1/2025                          |
| TT-003                           | Amazonas/Chachapoyas/Chontapampa | Animash                          | *Tropaelum*                      | *tuberosum*                      | 3/2/2025                          |
| TT-004                           | Amazonas/Chachapoyas/Chontapampa | Animash amarilla                 | *Tropaelum*                      | *tuberosum*                      | 3/2/2025                          |
| TT-005                           | Cajamarca/Cajamarca              | Negra-negra                      | *Tropaelum*                      | *tuberosum*                      | 29/04/2025                        |
| TT-006                           | Cajamarca/Cajamarca              | Larg\_black                      | *Tropaelum*                      | *tuberosum*                      | 29/04/2025                        |
| TT-007                           | Cajamarca/Cajamarca              | Yellow\_clear                    | *Tropaelum*                      | *tuberosum*                      | 29/04/2025                        |
| TT-008                           | Cajamarca/Cajamarca              | Yellow                           | *Tropaelum*                      | *tuberosum*                      | 29/04/2025                        |
| TT-009                           | Chachapoyas/Amazonas             | Morada                           | *Tropaelum*                      | *tuberosum*                      | 14/05/2025                        |
| TT-010                           | Colcamar/Amazonas                | Raya\_h                          | *Tropaelum*                      | *tuberosum*                      | 14/05/2025                        |
| TT-011                           | Colcamar/Amazonas                | Lis\_black                       | *Tropaelum*                      | *tuberosum*                      | 14/05/2025                        |




: base de datos {#tbl:id.59306923ted5}



¿Cuál es la variabilidad morfológica, fisiológica, bioquímica y molecular de diez accesiones de mashua (*Tropaeolum tuberosum*)?



la siguiente figura representa  ([Figure 1](?tab=t.0#bookmark=id.dn9uqrrcbaz))

![base](img_0.jpg){#fig:id.dn9uqrrcbaz}





Además, estudios recientes han mostrado variabilidad significativa en sus características fisiológicas, como su resistencia al frío y a las plagas, y su adaptación a suelos pobres, lo que la convierte en un cultivo resiliente en condiciones de estrés abióticos [[1]](https://www.zotero.org/google-docs/?lfvorK). Estos estudios también han destacado la importancia de comprender cómo los tratamientos postcosecha, como la exposición al sol, afectan la concentración de compuestos bioactivos como los flavonoides y las antocianinas, contribuyendo a la mejora de la calidad de los tubérculos [[2]](https://www.zotero.org/google-docs/?yjeShd)

referencias 

Aguilar-Galvez, A., Pedreschi, R., Carpentier, S., Chirinos, R., García-Ríos, D., & Campos, D. (2020). Análisis proteómico de tubérculos de mashua ( *Tropaeolum tuberosum* ) sometidos a tratamientos poscosecha. *Food Chemistry*, *305*, 125485. https://doi.org/10.1016/j.foodchem.2019.125485

Castañeta, G., Miranda-Flores, D., Bascopé, M., & Peñarrieta, J. M. (2024). Characterization of carotenoids, proximal analysis, phenolic compounds, anthocyanidins and antioxidant capacity of an underutilized tuber (Tropaeolum tuberosum) from Bolivia. *Discover Food*, *4*(1), 9. https://doi.org/10.1007/s44187-024-00078-8

Mirano Papel, M. E. (2018). Caracterización morfológica de 113 entradas de Mashua(Tropaeolum Tuberosum), en el sector de Chiri Unuyoc Kayra—Cusco. *Universidad Nacional de San Antonio Abad del Cusco*. https://repositorio.unsaac.edu.pe/handle/20.500.12918/4757